<?php 
$botToken = "5649865301:AAEtftEhsfXjV5qB1240X1b15hFvNfwD48E"; // Bot Baru -> Add @BotFather, Klik Start, Kasih nama bot, copy Access Token lalu paste disini
$chatID   = "5868274039"; // Ganti ChatId -> Add @chatIDrobot di telegram, klik start, copy chatId lalu Paste disini

// Note, Akun telegram kamu harus Join/Bergabung ke BOT yang kamu buat

function sendMessage($chatID, $messaggio, $token) {
    $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatID;
    $url = $url . "&text=" . urlencode($messaggio) . "&parse_mode=html";
    $ch = curl_init();
    $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
?>